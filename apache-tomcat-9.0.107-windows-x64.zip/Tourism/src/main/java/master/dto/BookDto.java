package master.dto;

public class BookDto {
	private String tid;
	private String hid;
	private String rtype;
	private String bkdt;
	private String uname;
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getHid() {
		return hid;
	}
	public void setHid(String hid) {
		this.hid = hid;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public String getBkdt() {
		return bkdt;
	}
	public void setBkdt(String bkdt) {
		this.bkdt = bkdt;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
   
     
} 
